const TelegramBot = require('node-telegram-bot-api');
require('dotenv').config();

const { addWallet, removeWallet, listWallets } = require('./database');
const { validateAddress } = require('./utils/validators');

const token = process.env.TELEGRAM_BOT_TOKEN;
let bot;

function initBot() {
  if (!token) {
    console.warn('TELEGRAM_BOT_TOKEN not provided in environment variables. Bot will not start.');
    return null;
  }

  bot = new TelegramBot(token, { polling: true });

  // /start command
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const welcomeMessage = `
👋 Welcome to Crypto Tracker Bot!

Monitor your crypto wallet transactions across multiple blockchains in real-time.

Commands:
/addwallet <address> <blockchain> - Track a new wallet
/removewallet <address> - Stop tracking a wallet
/list - Show all tracked wallets
/help - Show this message

Supported blockchains: Ethereum, Bitcoin
    `;
    bot.sendMessage(chatId, welcomeMessage.trim());
  });

  // /addwallet command
  bot.onText(/\/addwallet (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const address = match[1].trim();
    const blockchain = match[2].trim().toLowerCase();

    if (!['ethereum', 'bitcoin'].includes(blockchain)) {
      return bot.sendMessage(chatId, '❌ Unsupported blockchain. Please use "ethereum" or "bitcoin".');
    }

    if (!validateAddress(address, blockchain)) {
      return bot.sendMessage(chatId, `❌ Invalid ${blockchain} address format.`);
    }

    const result = await addWallet(chatId, address, blockchain);
    if (result.success) {
      bot.sendMessage(chatId, `✅ Successfully started tracking ${blockchain} wallet: \`${address}\``, { parse_mode: 'Markdown' });
    } else {
      bot.sendMessage(chatId, `⚠️ Failed to add wallet: ${result.error}`);
    }
  });

  bot.onText(/\/addwallet$/, (msg) => {
    bot.sendMessage(msg.chat.id, 'Usage: /addwallet <address> <blockchain>\nExample: /addwallet 0x123... ethereum');
  });

  // /removewallet command
  bot.onText(/\/removewallet (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const address = match[1].trim();

    const result = await removeWallet(chatId, address);
    if (result.success) {
      bot.sendMessage(chatId, `✅ Stopped tracking wallet: \`${address}\``, { parse_mode: 'Markdown' });
    } else {
      bot.sendMessage(chatId, '⚠️ Wallet not found or could not be removed.');
    }
  });

  bot.onText(/\/removewallet$/, (msg) => {
    bot.sendMessage(msg.chat.id, 'Usage: /removewallet <address>');
  });

  // /list command
  bot.onText(/\/list/, async (msg) => {
    const chatId = msg.chat.id;
    const wallets = await listWallets(chatId);

    if (wallets.length === 0) {
      return bot.sendMessage(chatId, 'You are not tracking any wallets yet. Use /addwallet to add one.');
    }

    let response = '📋 **Your Tracked Wallets:**\n\n';
    wallets.forEach((w, index) => {
      response += `${index + 1}. \`${w.address}\` (${w.blockchain})\n`;
    });

    bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
  });

  return bot;
}

function getBot() {
  return bot;
}

module.exports = {
  initBot,
  getBot
};
