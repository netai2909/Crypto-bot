const axios = require('axios');
require('dotenv').config();

const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY;

function getApiEndpoint(blockchain) {
  const chain = blockchain.toLowerCase();
  switch (chain) {
    case 'ethereum':
      return 'https://api.etherscan.io/api';
    // Add other EVM chains here if we get their keys, e.g.:
    // case 'polygon': return 'https://api.polygonscan.com/api';
    // case 'bsc': return 'https://api.bscscan.com/api';
    default:
      return 'https://api.etherscan.io/api'; // Defaulting to Ethereum
  }
}

function getExplorerUrl(blockchain, txHash) {
  const chain = blockchain.toLowerCase();
  switch (chain) {
    case 'ethereum': return `https://etherscan.io/tx/${txHash}`;
    // case 'polygon': return `https://polygonscan.com/tx/${txHash}`;
    // case 'bsc': return `https://bscscan.com/tx/${txHash}`;
    default: return `https://etherscan.io/tx/${txHash}`;
  }
}

function getSymbol(blockchain) {
  const chain = blockchain.toLowerCase();
  switch (chain) {
    case 'ethereum': return 'ETH';
    // case 'polygon': return 'MATIC';
    // case 'bsc': return 'BNB';
    default: return 'ETH';
  }
}

async function getLatestEVMTransactions(address, blockchain) {
  const endpoint = getApiEndpoint(blockchain);
  // Using etherscan API to get normal transactions by address
  const url = `${endpoint}?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&page=1&offset=5&sort=desc&apikey=${ETHERSCAN_API_KEY}`;

  try {
    const response = await axios.get(url);
    if (response.data.status === '1' && response.data.result.length > 0) {
      const txs = response.data.result;
      
      // Map to standard format
      return txs.map(tx => {
        const isIncoming = tx.to.toLowerCase() === address.toLowerCase();
        return {
          hash: tx.hash,
          blockchain: blockchain,
          walletAddress: address,
          incoming: isIncoming,
          amount: (parseInt(tx.value) / 1e18).toFixed(6), // Convert Wei to ETH
          symbol: getSymbol(blockchain),
          timestamp: parseInt(tx.timeStamp),
          explorerUrl: getExplorerUrl(blockchain, tx.hash)
        };
      });
    }
    return [];
  } catch (error) {
    console.error(`Error fetching EVM transactions for ${address}:`, error.message);
    return [];
  }
}

module.exports = {
  getLatestEVMTransactions
};
