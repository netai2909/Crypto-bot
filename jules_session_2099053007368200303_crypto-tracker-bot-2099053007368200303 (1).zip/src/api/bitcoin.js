const axios = require('axios');

async function getLatestBTCTransactions(address) {
  const url = `https://blockstream.info/api/address/${address}/txs`;

  try {
    const response = await axios.get(url);
    const txs = response.data;
    
    if (txs && txs.length > 0) {
      return txs.map(tx => {
        let incoming = false;
        let amountSats = 0;

        // Calculate amount and direction
        // Check if address is in inputs (outgoing)
        const isOutgoing = tx.vin.some(vin => vin.prevout && vin.prevout.scriptpubkey_address === address);
        
        if (isOutgoing) {
          incoming = false;
          // To get exactly how much was sent *to others*, we'd look at vout that aren't the sender
          // This is a simplification:
          const sentToOthers = tx.vout
            .filter(vout => vout.scriptpubkey_address !== address)
            .reduce((sum, vout) => sum + vout.value, 0);
          amountSats = sentToOthers;
        } else {
          incoming = true;
          // Calculate received amount
          const received = tx.vout
            .filter(vout => vout.scriptpubkey_address === address)
            .reduce((sum, vout) => sum + vout.value, 0);
          amountSats = received;
        }

        return {
          hash: tx.txid,
          blockchain: 'Bitcoin',
          walletAddress: address,
          incoming: incoming,
          amount: (amountSats / 1e8).toFixed(6), // Convert Sats to BTC
          symbol: 'BTC',
          timestamp: tx.status.block_time || Math.floor(Date.now() / 1000), // unconfirmed txs don't have block_time
          explorerUrl: `https://blockstream.info/tx/${tx.txid}`
        };
      });
    }
    return [];
  } catch (error) {
    console.error(`Error fetching BTC transactions for ${address}:`, error.message);
    return [];
  }
}

module.exports = {
  getLatestBTCTransactions
};
