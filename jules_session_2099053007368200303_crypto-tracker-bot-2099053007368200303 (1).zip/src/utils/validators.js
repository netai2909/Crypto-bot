const { isAddress } = require('ethers');

function isValidEVMAddress(address) {
  return isAddress(address);
}

function isValidBTCAddress(address) {
  // Basic regex for legacy, SegWit, and native SegWit (bech32) Bitcoin addresses
  const btcRegex = /^(1[a-km-zA-HJ-NP-Z1-9]{25,34})|(3[a-km-zA-HJ-NP-Z1-9]{25,34})|(bc1[a-zA-HJ-NP-Z0-9]{39,59})$/;
  return btcRegex.test(address);
}

function validateAddress(address, blockchain) {
  const chain = blockchain.toLowerCase();
  if (['ethereum', 'polygon', 'bsc', 'arbitrum'].includes(chain)) {
    return isValidEVMAddress(address);
  } else if (chain === 'bitcoin') {
    return isValidBTCAddress(address);
  }
  // If blockchain is unsupported or unknown
  return false;
}

module.exports = {
  validateAddress,
  isValidEVMAddress,
  isValidBTCAddress
};
