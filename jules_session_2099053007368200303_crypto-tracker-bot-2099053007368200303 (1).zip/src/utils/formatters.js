function shortenAddress(address) {
  if (!address || address.length < 10) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function formatTransactionMessage(tx) {
  const direction = tx.incoming ? '⬇️ INCOMING' : '⬆️ OUTGOING';
  const explorerUrl = tx.explorerUrl ? `[View on Explorer](${tx.explorerUrl})` : '';
  
  return `
🚨 **New Transaction Detected** 🚨

**Blockchain:** ${tx.blockchain}
**Wallet:** \`${shortenAddress(tx.walletAddress)}\`
**Direction:** ${direction}
**Amount:** ${tx.amount} ${tx.symbol}
**Timestamp:** ${new Date(tx.timestamp * 1000).toLocaleString()}

${explorerUrl}
  `.trim();
}

module.exports = {
  shortenAddress,
  formatTransactionMessage
};
