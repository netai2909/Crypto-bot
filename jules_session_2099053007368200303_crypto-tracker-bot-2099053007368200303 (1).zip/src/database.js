const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');

const dbPath = path.resolve(__dirname, '../database.sqlite');

let db;

async function connectDb() {
  db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS wallets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id TEXT NOT NULL,
      address TEXT NOT NULL,
      blockchain TEXT NOT NULL,
      last_tx_hash TEXT,
      UNIQUE(chat_id, address, blockchain)
    );
  `);
  
  return db;
}

async function addWallet(chatId, address, blockchain) {
  try {
    const result = await db.run(
      'INSERT INTO wallets (chat_id, address, blockchain) VALUES (?, ?, ?)',
      [chatId, address, blockchain]
    );
    return { success: true, id: result.lastID };
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT') {
      return { success: false, error: 'Wallet already exists for this chat and blockchain.' };
    }
    return { success: false, error: error.message };
  }
}

async function removeWallet(chatId, address) {
  try {
    const result = await db.run(
      'DELETE FROM wallets WHERE chat_id = ? AND address = ?',
      [chatId, address]
    );
    return { success: result.changes > 0 };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function listWallets(chatId) {
  try {
    const wallets = await db.all('SELECT * FROM wallets WHERE chat_id = ?', [chatId]);
    return wallets;
  } catch (error) {
    console.error('Error listing wallets:', error);
    return [];
  }
}

async function getAllTrackedWallets() {
  try {
    const wallets = await db.all('SELECT * FROM wallets');
    return wallets;
  } catch (error) {
    console.error('Error getting all tracked wallets:', error);
    return [];
  }
}

async function updateLastTxHash(id, txHash) {
  try {
    await db.run('UPDATE wallets SET last_tx_hash = ? WHERE id = ?', [txHash, id]);
    return true;
  } catch (error) {
    console.error('Error updating last tx hash:', error);
    return false;
  }
}

module.exports = {
  connectDb,
  addWallet,
  removeWallet,
  listWallets,
  getAllTrackedWallets,
  updateLastTxHash
};
