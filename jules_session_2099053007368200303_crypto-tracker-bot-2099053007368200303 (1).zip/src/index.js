require('dotenv').config();
const { connectDb } = require('./database');
const { initBot } = require('./bot');
const { startTracker } = require('./tracker');

async function main() {
  try {
    console.log('Connecting to database...');
    await connectDb();
    console.log('Database connected.');

    console.log('Initializing Telegram Bot...');
    const bot = initBot();
    if (bot) {
      console.log('Telegram Bot is running.');
    } else {
      console.log('Telegram Bot initialization skipped (check TELEGRAM_BOT_TOKEN).');
    }

    startTracker();
  } catch (error) {
    console.error('Error starting application:', error);
    process.exit(1);
  }
}

main();
