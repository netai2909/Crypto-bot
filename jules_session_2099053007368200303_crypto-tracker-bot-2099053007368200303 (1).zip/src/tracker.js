const { getAllTrackedWallets, updateLastTxHash } = require('./database');
const { getLatestEVMTransactions } = require('./api/evm');
const { getLatestBTCTransactions } = require('./api/bitcoin');
const { formatTransactionMessage } = require('./utils/formatters');
const { getBot } = require('./bot');

const POLL_INTERVAL_MS = 60000; // 60 seconds

async function checkWallets() {
  const wallets = await getAllTrackedWallets();
  const bot = getBot();

  for (const wallet of wallets) {
    let latestTxs = [];
    
    if (['ethereum', 'polygon', 'bsc', 'arbitrum'].includes(wallet.blockchain)) {
      latestTxs = await getLatestEVMTransactions(wallet.address, wallet.blockchain);
    } else if (wallet.blockchain === 'bitcoin') {
      latestTxs = await getLatestBTCTransactions(wallet.address);
    }

    if (latestTxs.length > 0) {
      // The transactions are usually sorted desc by timestamp, so [0] is the most recent
      const mostRecentTx = latestTxs[0];

      if (wallet.last_tx_hash !== mostRecentTx.hash) {
        // Find which transactions are new since last_tx_hash
        // If last_tx_hash is null (first run), we just alert the most recent one (or none, to avoid spam, but here we alert the latest 1)
        let newTxs = [];
        if (!wallet.last_tx_hash) {
          newTxs = [mostRecentTx];
        } else {
          for (const tx of latestTxs) {
            if (tx.hash === wallet.last_tx_hash) break;
            newTxs.push(tx);
          }
        }

        // Send notifications
        if (bot) {
          // Process in reverse to send oldest "new" transaction first
          for (const tx of newTxs.reverse()) {
            const message = formatTransactionMessage(tx);
            try {
              await bot.sendMessage(wallet.chat_id, message, { parse_mode: 'Markdown', disable_web_page_preview: true });
            } catch (error) {
              console.error(`Failed to send message to chat ${wallet.chat_id}:`, error.message);
            }
          }
        }

        // Update last_tx_hash in db
        await updateLastTxHash(wallet.id, mostRecentTx.hash);
      }
    }
  }
}

function startTracker() {
  console.log(`Starting wallet tracker. Polling every ${POLL_INTERVAL_MS / 1000} seconds...`);
  
  // Initial check
  checkWallets();

  // Schedule future checks
  setInterval(checkWallets, POLL_INTERVAL_MS);
}

module.exports = {
  startTracker,
  checkWallets // exported for testing
};
