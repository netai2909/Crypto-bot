# Crypto Tracker Bot

A production-ready Telegram bot that tracks crypto wallet transactions across multiple blockchains and notifies the user in real-time.

## Features

- **Multi-Chain Support**: Tracks Ethereum and Bitcoin.
- **Real-Time Notifications**: Polls for new transactions and sends detailed alerts (with explorer links).
- **Multi-User**: Uses SQLite to handle multiple users tracking multiple wallets.
- **Validations**: Automatically validates EVM and Bitcoin addresses before storing.

## Prerequisites

- Node.js (v18+ recommended)
- A Telegram Bot Token from [@BotFather](https://t.me/botfather)
- An API Key from [Etherscan](https://etherscan.io/apis) (for tracking Ethereum wallets)

## Setup Instructions

1. **Clone the repository**:
   ```bash
   git clone <repo-url>
   cd <repo-directory>
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Environment Variables**:
   Copy the example environment file and fill in your keys.
   ```bash
   cp .env.example .env
   ```
   Open `.env` and set:
   - `TELEGRAM_BOT_TOKEN`: Your bot token from BotFather.
   - `ETHERSCAN_API_KEY`: Your Etherscan API key.

4. **Run the bot**:
   ```bash
   npm start
   ```
   *Note: Ensure `package.json` has `"start": "node src/index.js"` under scripts.*

## How to Deploy

### Deploying to Railway
1. Create a [Railway](https://railway.app/) account.
2. Connect your GitHub repository.
3. In the Railway dashboard, go to the "Variables" tab and add:
   - `TELEGRAM_BOT_TOKEN`
   - `ETHERSCAN_API_KEY`
4. The application will build and deploy automatically. To persist the SQLite database, you should attach a Volume to the `/app` path or consider migrating the db code to use a hosted PostgreSQL/MongoDB.

### Deploying to a VPS (e.g., DigitalOcean, Linode)
1. SSH into your server and install Node.js and PM2.
   ```bash
   sudo npm install -g pm2
   ```
2. Clone the repository and install dependencies.
3. Setup `.env` file.
4. Run the app using PM2 to keep it alive:
   ```bash
   pm2 start src/index.js --name crypto-bot
   pm2 save
   pm2 startup
   ```

## Folder Structure

\`\`\`text
.
├── src/
│   ├── api/
│   │   ├── bitcoin.js      # Fetch BTC transactions using Blockstream
│   │   └── evm.js          # Fetch EVM transactions using Etherscan
│   ├── utils/
│   │   ├── formatters.js   # Message and address formatters
│   │   └── validators.js   # Wallet address validation
│   ├── bot.js              # Telegram bot command setup and handling
│   ├── database.js         # SQLite Database connection and queries
│   ├── tracker.js          # Polling loop to check for new transactions
│   └── index.js            # Main entry point
├── package.json
├── .env.example
└── README.md
\`\`\`
